<?php
namespace ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Calls;
use ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class ModifyNameServer extends Call
{
    public $action = "domains/:domain/nameservers/modify";
    
    public $type = parent::TYPE_POST;
}