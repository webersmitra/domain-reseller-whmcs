<?php
namespace ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Calls;
use ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class GetRegistrarLock extends Call
{
    public $action = "domains/:domain/lock";
    
    public $type = parent::TYPE_GET;
}