<?php
namespace ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Calls;
use ModulesGarden\DomainsReseller\Registrar\WHISCLOUD\Core\Call;

/**
 * Description of DeleteNameServer
 *
 * @author inbs
 */
class DeleteNameServer extends Call
{
    public $action = "domains/:domain/nameservers/delete";
    
    public $type = parent::TYPE_POST;
}